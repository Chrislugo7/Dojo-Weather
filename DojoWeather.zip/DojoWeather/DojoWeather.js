function remove(cls){
    document.querySelector("."+cls).remove()
}

function balloon() {
    alert("Loading weather report...");
}
function ball() {
    alert("Loading weather report...");
}
function bal() {
    alert("Loading weather report...");
}

/*
function remove_jz(cls){
      document.querySelector("."+cls).remove()
   }

   <div id="box1">
        <div class="test">
        <img onclick="connections()" class="fupa" src="./accept-circle.png" alt="">
        <img onclick="remove_jz('test')" class="fupa" src="./close-circle.png">
        <img id="jz" class="i" src="./alayne-s.jpg">
        <p id="todd" class="dust">Todd E</p>
        </div>
        <img onclick="connections()" class="fupa" src="./accept-circle.png" alt="">
        <img onclick="remove_3()" class="fupa" src="./close-circle.png">
        <img id="3" class="k" src="./adrien-s.jpg">
        <p class="dust">Phil K</p>
*/